export default { reactStrictMode: true, images: { formats: ["image/avif", "image/webp"] } };
