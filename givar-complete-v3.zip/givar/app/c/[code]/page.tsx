import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { fmt } from "@/lib/money";
import ClaimButton from "./ClaimButton";

const find = (code: string) => prisma.giveaway.findFirst({ where: { OR: [{ claimSlug: code }, { claimCode: code.toUpperCase() }], flagged: false } });

export async function generateMetadata({ params }: { params: { code: string } }): Promise<Metadata> {
  const g = await find(params.code);
  return g ? { title: `Claim ${g.title}`, description: `Claim your share of ${fmt(g.totalAmount, g.currency)} on Givar.`, alternates: { canonical: `/c/${g.claimSlug}` } } : { title: "Giveaway not found", robots: { index: false } };
}

export default async function ClaimPage({ params }: { params: { code: string } }) {
  const g = await find(params.code);
  const winners = g ? await prisma.claim.findMany({ where: { giveawayId: g.id }, orderBy: { createdAt: "desc" }, take: 10, include: { user: { select: { name: true } } } }) : [];
  const mask = (n?: string | null) => { const [a, b] = (n ?? "").split(" "); return a ? (b ? `${a} ${b[0]}.` : a) : "Someone"; };
  const expired = g && g.expiresAt < new Date(); const gone = g && g.winnersLeft === 0;
  return (
    <main className="mx-auto flex min-h-screen max-w-md items-center px-5">
      <div className="glass w-full space-y-4 rounded-2xl p-7">
        {!g ? <><h1 className="text-2xl font-bold">We can't find that giveaway</h1><p className="text-[var(--mut)]">Check the code or link and try again.</p></> : <>
          <h1 className="text-2xl font-bold">{g.title}</h1>
          {g.description && <p className="text-[var(--mut)]">{g.description}</p>}
          <p className="text-4xl font-bold">{fmt(g.totalAmount, g.currency)}</p>
          <p className="text-sm text-[var(--mut)]">{g.winnersLeft} of {g.winners} prizes left · ends {g.expiresAt.toLocaleDateString("en")}</p>
          {expired ? <p className="text-red-400">This giveaway has expired.</p> : gone ? <p className="text-red-400">All prizes have been claimed.</p> : <ClaimButton code={g.claimSlug} question={g.question} />}
          {winners.length > 0 && <div className="border-t border-[var(--line)] pt-4"><h2 className="font-semibold">Winners</h2>
            <ul className="mt-2 space-y-1 text-sm">{winners.map((w) => <li key={w.id} className="flex justify-between"><span>{mask(w.user.name)}</span><span className="text-[var(--mut)]">{fmt(w.amount, g.currency)} · {w.createdAt.toLocaleDateString("en")}</span></li>)}</ul></div>}
        </>}
      </div>
    </main>
  );
}
