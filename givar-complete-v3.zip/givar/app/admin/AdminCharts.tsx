"use client";
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts";
type Row = Record<string, string | number>;
const L = "#D8F24A", B = "#60a5fa";
function Card({ title, children }: { title: string; children: React.ReactElement }) {
  return <div className="glass rounded-2xl p-4"><h3 className="mb-3 text-sm font-semibold">{title}</h3><div className="h-56"><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div></div>;
}
const axes = <><CartesianGrid stroke="rgba(128,128,128,.2)" vertical={false} /><XAxis dataKey="day" tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 11 }} width={36} allowDecimals={false} /><Tooltip contentStyle={{ background: "#111", border: "1px solid #333", borderRadius: 12 }} /><Legend /></>;
export default function AdminCharts({ d }: { d: { visitors: Row[]; signups: Row[]; giveaways: Row[]; volume: Row[]; entries: Row[] } }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card title="Visitors (14 days)"><LineChart data={d.visitors}>{axes}<Line dataKey="views" name="Page views" stroke={L} dot={false} /><Line dataKey="unique" name="Unique visitors" stroke={B} dot={false} /></LineChart></Card>
      <Card title="Signups"><BarChart data={d.signups}>{axes}<Bar dataKey="signups" name="Signups" fill={L} radius={[6, 6, 0, 0]} /></BarChart></Card>
      <Card title="Giveaways created vs claimed"><BarChart data={d.giveaways}>{axes}<Bar dataKey="created" name="Created" fill={L} radius={[6, 6, 0, 0]} /><Bar dataKey="claimed" name="Claimed" fill={B} radius={[6, 6, 0, 0]} /></BarChart></Card>
      <Card title="Deposit volume (major units)"><LineChart data={d.volume}>{axes}<Line dataKey="NGN" stroke={L} dot={false} /><Line dataKey="USD" stroke={B} dot={false} /></LineChart></Card>
      <Card title="Contest entries"><BarChart data={d.entries}>{axes}<Bar dataKey="entries" name="Entries" fill={L} radius={[6, 6, 0, 0]} /></BarChart></Card>
    </div>
  );
}
