"use server";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { refundGiveaway } from "@/lib/refund";

// Every action re-checks the role on the server (hiding a button is not security) and writes an audit entry.
async function admin() { const s = await getServerSession(authOptions); if (s?.user.role !== "ADMIN") throw new Error("Forbidden"); return s.user.id; }
const audit = (adminId: string, action: string, target: string) => prisma.auditLog.create({ data: { adminId, action, target } });

export async function toggleBan(id: string) { const a = await admin(); const u = await prisma.user.findUniqueOrThrow({ where: { id } }); await prisma.user.update({ where: { id }, data: { banned: !u.banned } }); await audit(a, u.banned ? "unban_user" : "ban_user", id); revalidatePath("/admin"); }
export async function verifyKyc(id: string) { const a = await admin(); await prisma.user.update({ where: { id }, data: { kyc: "VERIFIED" } }); await audit(a, "verify_kyc", id); revalidatePath("/admin"); }
export async function flagGiveaway(id: string) { const a = await admin(); const g = await prisma.giveaway.findUniqueOrThrow({ where: { id } }); await prisma.giveaway.update({ where: { id }, data: { flagged: !g.flagged } }); await audit(a, g.flagged ? "unflag_giveaway" : "flag_giveaway", id); revalidatePath("/admin"); }
/** "Delete" = cancel: hide it and refund unclaimed escrow. Claims already paid are kept for the audit trail. */
export async function cancelGiveaway(id: string) { const a = await admin(); const refunded = await refundGiveaway(id); await prisma.giveaway.update({ where: { id }, data: { flagged: true } }); await audit(a, `cancel_giveaway(refund ${refunded})`, id); revalidatePath("/admin"); }
