import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { fmt } from "@/lib/money";
import { dailySeries } from "@/lib/series";
import AdminCharts from "./AdminCharts";
import { toggleBan, verifyKyc, flagGiveaway, cancelGiveaway } from "./actions";

export const metadata = { title: "Admin", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";
const N = 14;

export default async function Admin() {
  const s = await getServerSession(authOptions);
  if (s?.user.role !== "ADMIN") notFound(); // role guard: non-admins see a 404
  const since = new Date(Date.now() - N * 864e5);
  const [users, gCount, cCount, given, fees, views, signups, gNew, claims, deposits, entries, countries, sources, active, failed, userRows, gRows, cRows, tRows, eRows, aRows] = await Promise.all([
    prisma.user.count(), prisma.giveaway.count(), prisma.contest.count(),
    prisma.claim.aggregate({ _sum: { amount: true } }),
    prisma.transaction.findMany({ where: { type: "FEE", status: "SUCCESS" }, select: { amount: true, wallet: { select: { currency: true } } } }),
    prisma.analyticsEvent.findMany({ where: { type: "pageview", createdAt: { gte: since } }, select: { createdAt: true, visitorId: true } }),
    prisma.user.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    prisma.giveaway.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    prisma.claim.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    prisma.transaction.findMany({ where: { type: "DEPOSIT", status: "SUCCESS", createdAt: { gte: since } }, select: { createdAt: true, amount: true, wallet: { select: { currency: true } } } }),
    prisma.contestEntry.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    prisma.analyticsEvent.groupBy({ by: ["country"], where: { type: "pageview", country: { not: null } }, _count: true, orderBy: { _count: { country: "desc" } }, take: 6 }),
    prisma.analyticsEvent.groupBy({ by: ["source"], where: { type: "pageview" }, _count: true, orderBy: { _count: { source: "desc" } }, take: 6 }),
    prisma.user.findMany({ orderBy: [{ claims: { _count: "desc" } }], take: 5, select: { id: true, name: true, email: true, _count: { select: { claims: true, giveaways: true } } } }),
    prisma.analyticsEvent.findMany({ where: { type: "webhook_failed" }, orderBy: { createdAt: "desc" }, take: 8 }),
    prisma.user.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
    prisma.giveaway.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
    prisma.contest.findMany({ orderBy: { endsAt: "desc" }, take: 20, include: { _count: { select: { entries: true } } } }),
    prisma.transaction.findMany({ orderBy: { createdAt: "desc" }, take: 25, include: { wallet: { select: { currency: true } } } }),
    prisma.analyticsEvent.findMany({ where: { type: { not: "pageview" } }, orderBy: { createdAt: "desc" }, take: 25 }),
    prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
  ]);
  const rev = (c: "NGN" | "USD") => fees.filter((f) => f.wallet.currency === c).reduce((a, f) => a + f.amount, 0);
  // Unique visitors per day: dedupe by visitorId inside each day
  const perDay = (i: number) => new Set(views.filter((v) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (N - 1 - i)); return v.createdAt >= d && v.createdAt.getTime() < d.getTime() + 864e5; }).map((v) => v.visitorId)).size;
  const visitors = dailySeries(N, { views: views.map((v) => ({ at: v.createdAt })) }).map((r, i) => ({ ...r, unique: perDay(i) }));
  const charts = {
    visitors, signups: dailySeries(N, { signups: signups.map((x) => ({ at: x.createdAt })) }),
    giveaways: dailySeries(N, { created: gNew.map((x) => ({ at: x.createdAt })), claimed: claims.map((x) => ({ at: x.createdAt })) }),
    volume: dailySeries(N, { NGN: deposits.filter((t) => t.wallet.currency === "NGN").map((t) => ({ at: t.createdAt, v: t.amount / 100 })), USD: deposits.filter((t) => t.wallet.currency === "USD").map((t) => ({ at: t.createdAt, v: t.amount / 100 })) }),
    entries: dailySeries(N, { entries: entries.map((x) => ({ at: x.createdAt })) }),
  };
  const stat = (l: string, v: string | number) => <div className="glass rounded-2xl p-4"><p className="text-sm text-[var(--mut)]">{l}</p><p className="mt-1 text-2xl font-bold">{v}</p></div>;
  const btn = "rounded-full border border-[var(--line)] px-3 py-1 text-xs";
  return (
    <main className="mx-auto max-w-6xl space-y-6 px-5 py-8">
      <h1 className="text-2xl font-bold">Admin</h1>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {stat("Users", users)}{stat("Giveaways", gCount)}{stat("Given (claimed)", fmt(given._sum.amount ?? 0))}{stat("Contests", cCount)}{stat("Revenue (5%)", `${fmt(rev("NGN"))} + ${fmt(rev("USD"), "USD")}`)}
      </div>
      <AdminCharts d={charts} />
      <div className="grid gap-4 md:grid-cols-3">
        <div className="glass rounded-2xl p-4"><h3 className="font-semibold">Top countries</h3>{countries.map((c) => <p key={c.country} className="flex justify-between text-sm"><span>{c.country}</span><span>{c._count}</span></p>)}</div>
        <div className="glass rounded-2xl p-4"><h3 className="font-semibold">Traffic sources</h3>{sources.map((c) => <p key={c.source} className="flex justify-between text-sm"><span>{c.source}</span><span>{c._count}</span></p>)}</div>
        <div className="glass rounded-2xl p-4"><h3 className="font-semibold">Most active users</h3>{active.map((u) => <p key={u.id} className="flex justify-between text-sm"><span>{u.name ?? u.email}</span><span>{u._count.claims} claims · {u._count.giveaways} created</span></p>)}</div>
      </div>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Users</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">
        {userRows.map((u) => <tr key={u.id}><td className="py-2">{u.name ?? "—"}<br /><span className="text-xs text-[var(--mut)]">{u.email ?? u.phone}</span></td><td>KYC {u.kyc.toLowerCase()}</td><td>{u.banned ? "banned" : "active"}</td>
          <td className="space-x-2 text-right"><form className="inline" action={toggleBan.bind(null, u.id)}><button className={btn}>{u.banned ? "Unban" : "Ban"}</button></form>
            {u.kyc !== "VERIFIED" && <form className="inline" action={verifyKyc.bind(null, u.id)}><button className={btn}>Verify KYC</button></form>}</td></tr>)}</tbody></table></section>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Giveaways</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">
        {gRows.map((g) => <tr key={g.id}><td className="py-2">{g.title}</td><td>{fmt(g.totalAmount, g.currency)}</td><td>{g.winnersLeft}/{g.winners} left</td><td>{g.flagged ? "hidden" : "live"}</td>
          <td className="space-x-2 text-right"><form className="inline" action={flagGiveaway.bind(null, g.id)}><button className={btn}>{g.flagged ? "Unflag" : "Flag"}</button></form>
            <form className="inline" action={cancelGiveaway.bind(null, g.id)}><button className={btn}>Cancel &amp; refund</button></form></td></tr>)}</tbody></table></section>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Failed webhooks &amp; provisioning</h2>
        {failed.length === 0 ? <p className="text-sm text-[var(--mut)]">None. All webhooks processed.</p> : failed.map((f) => <p key={f.id} className="text-sm">{f.createdAt.toLocaleString("en")} · {f.path ?? f.type} · {String((f.meta as any)?.error ?? "").slice(0, 120)}</p>)}</section>

      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Contests</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">{cRows.map((c) => <tr key={c.id}><td className="py-2">{c.prize}</td><td>{c._count.entries}/{c.maxEntries} entries</td><td>{c.entryFee ? fmt(c.entryFee, c.currency) : "free"}</td><td>{c.drawnAt ? "drawn" : "open"}</td><td>{c.deliveredAt ? "prize delivered" : ""}</td></tr>)}</tbody></table></section>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Transactions</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">{tRows.map((x) => <tr key={x.id}><td className="py-2">{x.type.replaceAll("_", " ").toLowerCase()}</td><td>{x.status.toLowerCase()}</td><td>{fmt(x.amount, x.wallet.currency)}</td><td>{x.createdAt.toLocaleString("en")}</td><td className="font-mono text-xs">{x.reference}</td></tr>)}</tbody></table></section>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Event log (errors, webhooks, provisioning)</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">{eRows.map((e) => <tr key={e.id}><td className="py-2">{e.type}</td><td>{e.path}</td><td>{e.createdAt.toLocaleString("en")}</td><td className="text-xs">{String((e.meta as any)?.error ?? (e.meta as any)?.message ?? "").slice(0, 100)}</td></tr>)}</tbody></table></section>
      <section className="glass overflow-x-auto rounded-2xl p-4"><h2 className="mb-2 font-semibold">Admin audit log</h2><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">{aRows.map((a) => <tr key={a.id}><td className="py-2">{a.createdAt.toLocaleString("en")}</td><td>{a.action}</td><td className="font-mono text-xs">{a.target}</td></tr>)}</tbody></table></section>
    </main>
  );
}
