import { NextResponse } from "next/server";
import { listBanks } from "@/lib/payout";
export async function GET() { return NextResponse.json(await listBanks()); }
