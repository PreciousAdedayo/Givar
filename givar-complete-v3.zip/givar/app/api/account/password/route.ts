import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getUserId } from "@/lib/session";
import { limit } from "@/lib/ratelimit";
import { hashPassword, verifyPassword } from "@/lib/password";
export async function POST(req: Request) {
  const userId = await getUserId(); if (!userId) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  if (!(await limit(`pw:${userId}`, 5, 900))) return NextResponse.json({ error: "Too many attempts. Try again in a few minutes." }, { status: 429 });
  const p = z.object({ current: z.string().optional(), password: z.string().min(8).max(100) }).safeParse(await req.json());
  if (!p.success) return NextResponse.json({ error: "Use a new password of 8+ characters." }, { status: 400 });
  const me = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (me.passwordHash && !(p.data.current && verifyPassword(p.data.current, me.passwordHash))) return NextResponse.json({ error: "Your current password is wrong." }, { status: 400 });
  await prisma.user.update({ where: { id: userId }, data: { passwordHash: hashPassword(p.data.password) } });
  return NextResponse.json({ ok: true });
}
