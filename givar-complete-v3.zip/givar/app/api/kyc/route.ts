import { NextResponse } from "next/server";
import { createHmac } from "crypto";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { upgradeNgnAccount } from "@/lib/virtual-accounts";
import { getUserId } from "@/lib/session";
const B = z.object({ kind: z.enum(["BVN", "NIN"]), idNumber: z.string().regex(/^\d{11}$/) });
export async function POST(req: Request) {
  const userId = await getUserId(); if (!userId) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const p = B.safeParse(await req.json()); if (!p.success) return NextResponse.json({ error: "Enter your 11-digit BVN or NIN." }, { status: 400 });
  const idHash = createHmac("sha256", process.env.NEXTAUTH_SECRET ?? "").update(p.data.idNumber).digest("hex");
  if (await prisma.kycSubmission.findFirst({ where: { idHash, NOT: { userId } } })) return NextResponse.json({ error: "This ID is already linked to another account." }, { status: 409 });
  await prisma.$transaction([
    prisma.kycSubmission.create({ data: { userId, kind: p.data.kind, idHash, idLast4: p.data.idNumber.slice(-4), country: "NG" } }),
    prisma.user.update({ where: { id: userId }, data: { kyc: "PENDING", country: "NG" } }),
  ]);
  if (p.data.kind === "BVN") { // Flutterwave needs the raw BVN once to open a permanent account; we don't keep it
    const u = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
    await upgradeNgnAccount(u, p.data.idNumber).catch((e) => prisma.analyticsEvent.create({ data: { type: "provision_failed", meta: { userId, error: String(e) } } }));
  }
  return NextResponse.json({ ok: true });
}
