import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getUserId } from "@/lib/session";
import { toMinor } from "@/lib/money";
import { payoutsConfigured, resolveAccount, sendTransfer, settleWithdrawal } from "@/lib/payout";

const Body = z.object({ amount: z.number().min(500).max(5_000_000), bankCode: z.string().min(2).max(10), accountNumber: z.string().regex(/^\d{10}$/) });
const prod = process.env.NODE_ENV === "production";

export async function POST(req: Request) {
  const userId = await getUserId();
  if (!userId) return NextResponse.json({ error: "Sign in first." }, { status: 401 });
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (user.banned) return NextResponse.json({ error: "Your account can't withdraw." }, { status: 403 });
  if (prod && user.kyc !== "VERIFIED") return NextResponse.json({ error: "Verify your identity to withdraw." }, { status: 403 });
  if (prod && !payoutsConfigured()) return NextResponse.json({ error: "Withdrawals are temporarily unavailable." }, { status: 503 });
  const p = Body.safeParse(await req.json());
  if (!p.success) return NextResponse.json({ error: "Check the bank details and amount (₦500 to ₦5,000,000)." }, { status: 400 });

  // Look up the real account holder name; we never trust a name typed by the user
  const accountName = await resolveAccount(p.data.bankCode, p.data.accountNumber);
  if (!accountName) return NextResponse.json({ error: "We couldn't find that account. Check the bank and number." }, { status: 404 });

  const amount = toMinor(p.data.amount), reference = `wd_${randomUUID()}`;
  try {
    await prisma.$transaction(async (tx) => {
      const w = await tx.wallet.findUniqueOrThrow({ where: { userId_currency: { userId, currency: "NGN" } } });
      const ok = await tx.wallet.updateMany({ where: { id: w.id, balance: { gte: amount } }, data: { balance: { decrement: amount } } });
      if (ok.count === 0) throw new Error("INSUFFICIENT");
      await tx.transaction.create({ data: { walletId: w.id, type: "WITHDRAWAL", status: "PENDING", amount, reference, meta: { ...p.data, accountName } } });
    });
  } catch (e) {
    if (e instanceof Error && e.message === "INSUFFICIENT") return NextResponse.json({ error: "Not enough balance." }, { status: 402 });
    return NextResponse.json({ error: "Something went wrong. Try again." }, { status: 500 });
  }

  if (!payoutsConfigured()) { await settleWithdrawal(reference, true); return NextResponse.json({ ok: true, note: "dev mode: no real transfer" }); }

  const result = await sendTransfer({ reference, amountMinor: amount, ...p.data });
  if (result === "rejected") { await settleWithdrawal(reference, false); return NextResponse.json({ error: "Your bank transfer couldn't be started. Your money is back in your wallet." }, { status: 502 }); }
  if (result === "unknown") await prisma.analyticsEvent.create({ data: { type: "webhook_failed", path: "payout_unknown", meta: { reference, error: "Transfer outcome unknown; reconcile before refunding" } } });
  return NextResponse.json({ ok: true }); // final result arrives via the transfer.completed webhook
}
