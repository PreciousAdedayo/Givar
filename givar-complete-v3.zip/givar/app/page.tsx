import Link from "next/link";
import { getServerSession } from "next-auth";
import { ArrowUpRight, ChevronRight, Gift, Landmark, Plus, Receipt, ShieldCheck, Sparkles, Trophy } from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { fmt } from "@/lib/money";
import Avatar from "@/components/Avatar";
import BalanceCard from "@/components/BalanceCard";
import ClaimByCode from "@/components/ClaimByCode";
import CopyButton from "@/components/CopyButton";
import ThemeToggle from "@/components/ThemeToggle";
import TxRow from "@/components/TxRow";

const faqs = [
  ["What is a giveaway link generator?", "Givar turns any amount of cash into a claim link and code you can share anywhere. Winners open the link and the money lands in their wallet."],
  ["How do I claim a giveaway by code?", "Sign in, enter the code (for example GV-8X2K91), and your wallet is credited instantly if prizes remain."],
  ["Is Givar an international giveaway platform?", "Yes. You get virtual account numbers to receive money from banks in Nigeria, the US, the UK and beyond."],
  ["Is the giveaway money safe?", "Funds are locked in escrow when a giveaway is created and released only as winners claim."],
];
const jsonLd = { "@context": "https://schema.org", "@graph": [
  { "@type": "Organization", name: "Givar", url: "https://givar.app", slogan: "Give. Claim. Win." },
  { "@type": "FAQPage", mainEntity: faqs.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })) },
] };
const actions = [
  { href: "/wallet#add", label: "Add money", Icon: Plus, grad: "grad-brand" },
  { href: "/wallet#withdraw", label: "Withdraw", Icon: ArrowUpRight, grad: "grad-soft" },
  { href: "/create", label: "Create", Icon: Gift, grad: "grad-brand" },
  { href: "/giveaways", label: "Giveaways", Icon: Sparkles, grad: "grad-soft" },
  { href: "/contests", label: "Contests", Icon: Trophy, grad: "grad-soft" },
  { href: "/wallet", label: "Wallet", Icon: Landmark, grad: "grad-soft" },
  { href: "/transactions", label: "History", Icon: Receipt, grad: "grad-soft" },
  { href: "/kyc", label: "Verify ID", Icon: ShieldCheck, grad: "grad-soft" },
];

async function loadMe(uid: string) {
  const [me, wallets, accounts, txs] = await Promise.all([
    prisma.user.findUniqueOrThrow({ where: { id: uid } }),
    prisma.wallet.findMany({ where: { userId: uid } }),
    prisma.virtualAccount.findMany({ where: { userId: uid }, orderBy: { currency: "asc" } }),
    prisma.transaction.findMany({ where: { wallet: { userId: uid } }, orderBy: { createdAt: "desc" }, take: 5, include: { wallet: { select: { currency: true } } } }),
  ]);
  return { me, wallets, accounts, txs };
}

export default async function Home() {
  const s = await getServerSession(authOptions);
  const data = s ? await loadMe(s.user.id) : null;
  const [giveaways, contests] = await Promise.all([
    prisma.giveaway.findMany({ where: { flagged: false, expiresAt: { gt: new Date() }, winnersLeft: { gt: 0 } }, orderBy: { createdAt: "desc" }, take: 3 }),
    prisma.contest.findMany({ where: { drawnAt: null, endsAt: { gt: new Date() } }, orderBy: { endsAt: "asc" }, take: 2, include: { _count: { select: { entries: true } } } }),
  ]);
  const bal = (c: "NGN" | "USD") => data?.wallets.find((w) => w.currency === c);
  const nudge = data && (!data.me.phoneVerified ? { href: "/verify-phone", t: "Verify your phone", d: "Needed to claim giveaways." } : data.me.kyc !== "VERIFIED" ? { href: "/kyc", t: "Verify your identity", d: data.me.kyc === "PENDING" ? "Under review. We'll let you know." : "Unlock withdrawals and a permanent naira account." } : null);

  return (
    <main className="mx-auto max-w-5xl px-4 pb-10 pt-4 md:px-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      {data ? (
        <div className="mb-4 flex items-center justify-between md:hidden">
          <Link href="/account" className="flex items-center gap-3"><Avatar name={data.me.name} image={data.me.image} size={44} /><span><span className="block text-xs text-[var(--mut)]">Welcome back</span><span className="font-semibold">{data.me.name?.split(" ")[0] ?? "there"}</span></span></Link>
          <ThemeToggle />
        </div>
      ) : null}
      <h1 className={data ? "sr-only" : "hidden"}>Givar dashboard</h1>

      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <div className="space-y-5">
          {data ? (
            <BalanceCard ngn={fmt(bal("NGN")?.balance ?? 0)} usd={fmt(bal("USD")?.balance ?? 0, "USD")} held={fmt(bal("NGN")?.locked ?? 0)} />
          ) : (
            <section className="grad-brand shadow-glow relative overflow-hidden rounded-3xl p-6">
              <div className="pointer-events-none absolute -right-12 -top-12 h-48 w-48 rounded-full bg-white/30 blur-2xl" />
              <h1 className="relative text-3xl font-bold leading-tight tracking-tight sm:text-4xl">The Global Giveaway Platform - Create, Share &amp; Claim Cash in Seconds</h1>
              <p className="relative mt-3 max-w-[48ch] text-sm font-medium">Give. Claim. Win. Get your own naira and dollar account numbers and receive money from any bank worldwide.</p>
              <div className="relative mt-5 flex gap-3"><Link href="/auth" className="rounded-full bg-[#0a0a0a] px-6 py-3 text-sm font-semibold text-[#D8F24A]">Create free account</Link><Link href="/giveaways" className="rounded-full bg-white/50 px-6 py-3 text-sm font-semibold">Browse giveaways</Link></div>
            </section>
          )}

          <nav aria-label="Quick actions" className="glass grid grid-cols-4 gap-y-5 rounded-3xl p-4">
            {actions.map((a) => (
              <Link key={a.label} href={data || ["/giveaways", "/contests"].includes(a.href) ? a.href : "/auth"} className="flex flex-col items-center gap-2 text-center text-xs font-medium">
                <span className={`${a.grad} grid h-12 w-12 place-items-center rounded-2xl shadow-lg`}><a.Icon size={22} aria-hidden /></span>{a.label}
              </Link>
            ))}
          </nav>

          {nudge && <Link href={nudge.href} className="grad-dark flex items-center gap-3 rounded-2xl p-4"><ShieldCheck size={26} aria-hidden /><span className="flex-1"><b className="block">{nudge.t}</b><span className="text-sm opacity-90">{nudge.d}</span></span><ChevronRight aria-hidden /></Link>}

          <ClaimByCode />

          {data && (
            <section aria-labelledby="acc"><h2 id="acc" className="mb-2 font-semibold">Receive money</h2>
              <p className="mb-3 text-xs text-[var(--mut)]">Your Givar accounts. Receive money from any bank in Nigeria, US, UK, Worldwide.</p>
              <div className="flex snap-x gap-3 overflow-x-auto pb-1">
                {data.accounts.length === 0 && <p className="glass rounded-2xl p-4 text-sm text-[var(--mut)]">Your accounts are being set up. Refresh in a moment.</p>}
                {data.accounts.map((a) => (
                  <div key={a.id} className={`${a.currency === "NGN" ? "grad-brand" : "grad-dark"} min-w-[250px] snap-start rounded-2xl p-4`}>
                    <div className="flex items-center justify-between text-xs opacity-90"><span>{a.currency} · {a.bankName}</span><CopyButton value={a.accountNumber} label={`Copy ${a.currency} account number`} /></div>
                    <p className="mt-1 font-mono text-2xl tracking-wider">{a.accountNumber}</p><p className="text-xs opacity-90">{a.accountName}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {data && (
            <section className="glass rounded-3xl p-4" aria-labelledby="rt">
              <div className="flex items-center justify-between"><h2 id="rt" className="font-semibold">Recent transactions</h2><Link href="/transactions" className="flex items-center text-sm text-lime-givar">See all<ChevronRight size={16} aria-hidden /></Link></div>
              {data.txs.length === 0
                ? <p className="py-6 text-center text-sm text-[var(--mut)]">No transactions yet. <Link href="/wallet#add" className="text-lime-givar underline">Add money</Link> to get started.</p>
                : <ul className="mt-1 divide-y divide-[var(--line)]">{data.txs.map((t) => <TxRow key={t.id} t={t} />)}</ul>}
            </section>
          )}
        </div>

        <div className="space-y-5">
          <section aria-labelledby="lg"><div className="mb-2 flex items-center justify-between"><h2 id="lg" className="font-semibold">Live giveaways</h2><Link href="/giveaways" className="text-sm text-lime-givar">See all</Link></div>
            {giveaways.length === 0 ? <p className="glass rounded-2xl p-4 text-sm text-[var(--mut)]">No live giveaways right now. <Link href="/create" className="text-lime-givar underline">Start one</Link>.</p> :
              <ul className="space-y-3">{giveaways.map((g) => (
                <li key={g.id}><Link href={`/c/${g.claimSlug}`} className="glass block rounded-2xl p-4">
                  <div className="flex items-start justify-between"><span className="font-medium">{g.title}</span><span className="text-xl font-bold">{fmt(g.totalAmount, g.currency)}</span></div>
                  <div className="my-3 h-2 overflow-hidden rounded-full bg-[var(--line)]"><div className="grad-brand h-full rounded-full" style={{ width: `${((g.winners - g.winnersLeft) / g.winners) * 100}%` }} /></div>
                  <div className="flex items-center justify-between text-xs text-[var(--mut)]"><span>{g.winnersLeft} of {g.winners} left</span><span className="bg-lime-givar rounded-full px-3 py-1 text-sm font-semibold">Claim</span></div>
                </Link></li>))}</ul>}
          </section>
          <section aria-labelledby="lc"><div className="mb-2 flex items-center justify-between"><h2 id="lc" className="font-semibold">Win a prize</h2><Link href="/contests" className="text-sm text-lime-givar">See all</Link></div>
            <ul className="space-y-3">{contests.length === 0 && <li className="glass rounded-2xl p-4 text-sm text-[var(--mut)]">No open contests. <Link href="/contests/create" className="text-lime-givar underline">Host one</Link>.</li>}
              {contests.map((c) => (
                <li key={c.id}><Link href={`/contests/${c.id}`} className="grad-dark flex items-center gap-3 rounded-2xl p-4"><Trophy size={26} aria-hidden /><span className="flex-1"><b className="block">{c.prize}</b><span className="text-sm opacity-90">{c.entryFee ? `Entry ${fmt(c.entryFee, c.currency)}` : "Free entry"} · {c._count.entries}/{c.maxEntries} joined</span></span><ChevronRight aria-hidden /></Link></li>))}</ul>
          </section>
        </div>
      </div>

      {!data && (
        <>
          <section className="mt-10" aria-labelledby="how"><h2 id="how" className="text-2xl font-bold">How it works</h2>
            <ol className="mt-4 grid gap-3 sm:grid-cols-3">{[["Create", "Set an amount and winners. The money is locked in escrow."], ["Share", "Get a link and code like GV-8X2K91. Post it anywhere."], ["Claim", "Winners are paid to their wallet the moment they claim."]].map(([t, d], i) => (
              <li key={t} className="glass rounded-2xl p-4"><span className="text-sm font-semibold text-lime-givar">Step {i + 1}</span><h3 className="mt-1 font-semibold">{t}</h3><p className="mt-1 text-sm text-[var(--mut)]">{d}</p></li>))}</ol></section>
          <section className="mt-10 max-w-3xl" aria-labelledby="faq"><h2 id="faq" className="text-2xl font-bold">Questions</h2>
            <div className="mt-3 divide-y divide-[var(--line)]">{faqs.map(([q, a]) => <details key={q} className="py-4"><summary className="cursor-pointer font-semibold">{q}</summary><p className="mt-2 text-[var(--mut)]">{a}</p></details>)}</div></section>
          <p className="mt-10 text-center text-sm text-[var(--mut)]">© {new Date().getFullYear()} Givar.app · Give. Claim. Win.</p>
        </>
      )}
    </main>
  );
}
