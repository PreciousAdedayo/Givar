"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const input = "w-full rounded-xl border border-[var(--line)] bg-transparent px-4 py-3 outline-none focus:border-lime-givar";
export default function Create() {
  const r = useRouter();
  const [f, setF] = useState({ title: "", description: "", currency: "NGN", amount: "", winners: "1", distribution: "EQUAL", claimType: "LINK", expiresInHours: "24", question: "" });
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ claimCode: string; claimLink: string } | null>(null);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr("");
    const res = await fetch("/api/giveaways", { method: "POST", body: JSON.stringify({ ...f, amount: +f.amount, winners: +f.winners, expiresInHours: +f.expiresInHours, description: f.description || undefined, question: f.question || undefined }) });
    const j = await res.json(); setBusy(false);
    if (res.status === 401) return r.push("/auth");
    if (!res.ok) return setErr(j.error);
    setDone(j);
  }
  if (done) {
    const msg = encodeURIComponent(`Claim my giveaway on Givar: ${done.claimLink} (code ${done.claimCode})`);
    return (
      <main className="mx-auto max-w-md px-5 py-10"><div className="glass space-y-4 rounded-2xl p-7">
        <h1 className="text-2xl font-bold">Giveaway is live</h1>
        <p className="font-mono text-2xl tracking-widest">{done.claimCode}</p>
        <p className="break-all text-sm text-[var(--mut)]">{done.claimLink}</p>
        <div className="flex flex-wrap gap-2">
          <a className="rounded-full bg-lime-givar px-4 py-2 font-semibold text-black" href={`https://wa.me/?text=${msg}`}>WhatsApp</a>
          <a className="glass rounded-full px-4 py-2" href={`https://twitter.com/intent/tweet?text=${msg}`}>X</a>
          <a className="glass rounded-full px-4 py-2" href={`https://t.me/share/url?url=${encodeURIComponent(done.claimLink)}&text=${msg}`}>Telegram</a>
          <button className="glass rounded-full px-4 py-2" onClick={() => navigator.clipboard.writeText(done.claimLink)}>Copy link</button>
        </div></div></main>
    );
  }
  return (
    <main className="mx-auto max-w-lg px-5 py-10">
      <form onSubmit={submit} className="glass space-y-4 rounded-2xl p-7">
        <h1 className="text-2xl font-bold">Create a giveaway</h1>
        <input className={input} placeholder="Title" value={f.title} onChange={set("title")} required minLength={3} />
        <textarea className={input} placeholder="Description (optional)" value={f.description} onChange={set("description")} />
        <div className="grid grid-cols-3 gap-3">
          <select className={input} value={f.currency} onChange={set("currency")}><option>NGN</option><option>USD</option></select>
          <input className={`${input} col-span-2`} type="number" min="1" step="any" placeholder="Total amount" value={f.amount} onChange={set("amount")} required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <input className={input} type="number" min="1" max="1000" placeholder="Winners" value={f.winners} onChange={set("winners")} required />
          <select className={input} value={f.distribution} onChange={set("distribution")}><option value="EQUAL">Equal split</option><option value="RANDOM">Random amounts</option></select>
          <select className={input} value={f.claimType} onChange={set("claimType")}><option value="LINK">Claim by link</option><option value="CODE">Claim by code</option></select>
          <select className={input} value={f.expiresInHours} onChange={set("expiresInHours")}><option value="1">Expires in 1 hour</option><option value="24">1 day</option><option value="168">7 days</option><option value="720">30 days</option></select>
        </div>
        <input className={input} placeholder="Question winners must answer (optional)" value={f.question} onChange={set("question")} />
        <p className="text-sm text-[var(--mut)]">A 5% Givar fee is added. The giveaway amount is held safely until people claim it.</p>
        {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
        <button disabled={busy} className="w-full rounded-full bg-lime-givar py-3 font-semibold text-black disabled:opacity-60">{busy ? "Creating…" : "Create giveaway"}</button>
      </form>
    </main>
  );
}
