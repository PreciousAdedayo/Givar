import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getUserId } from "@/lib/session";
import SecurityForm from "./SecurityForm";
export const metadata = { title: "Security", robots: { index: false } };
export default async function Security() {
  const userId = await getUserId(); if (!userId) redirect("/auth");
  const me = await prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { passwordHash: true } });
  return <SecurityForm hasPassword={!!me.passwordHash} />;
}
