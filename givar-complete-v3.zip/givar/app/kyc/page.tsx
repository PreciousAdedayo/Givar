"use client";
import { useState } from "react";
const input = "w-full rounded-xl border border-[var(--line)] bg-transparent px-4 py-3 outline-none focus:border-lime-givar";
export default function Kyc() {
  const [f, setF] = useState({ kind: "BVN", idNumber: "" }); const [msg, setMsg] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); const r = await fetch("/api/kyc", { method: "POST", body: JSON.stringify(f) }); const j = await r.json();
    setMsg(r.ok ? "Submitted. We'll review it shortly." : j.error);
  }
  return (
    <main className="mx-auto max-w-md px-5 py-10"><form onSubmit={submit} className="glass space-y-4 rounded-2xl p-7">
      <h1 className="text-2xl font-bold">Verify your identity</h1>
      <p className="text-sm text-[var(--mut)]">Required to withdraw. We store only the last 4 digits and a one-way hash of your number.</p>
      <select className={input} value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option>BVN</option><option>NIN</option></select>
      <input className={input} inputMode="numeric" maxLength={11} placeholder="11-digit number" value={f.idNumber} onChange={(e) => setF({ ...f, idNumber: e.target.value })} required />
      <p className="text-sm text-[var(--mut)]">Outside Nigeria? ID document upload is coming soon.</p>
      {msg && <p role="status" className="text-sm">{msg}</p>}
      <button className="w-full rounded-full bg-lime-givar py-3 font-semibold text-black">Submit</button>
    </form></main>
  );
}
