"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Auth() {
  const r = useRouter();
  const [mode, setMode] = useState<"in" | "up">("up");
  const [f, setF] = useState({ name: "", identifier: "", password: "" });
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr("");
    if (mode === "up") {
      const res = await fetch("/api/register", { method: "POST", body: JSON.stringify(f) });
      if (!res.ok) { setErr((await res.json()).error); setBusy(false); return; }
    }
    const res = await signIn("credentials", { identifier: f.identifier, password: f.password, redirect: false });
    setBusy(false);
    if (res?.error) return setErr("Wrong email, phone or password.");
    r.push("/");
  }
  const input = "w-full rounded-xl border border-[var(--line)] bg-transparent px-4 py-3 outline-none focus:border-lime-givar";
  return (
    <main className="mx-auto flex min-h-screen max-w-md items-center px-5">
      <form onSubmit={submit} className="glass w-full space-y-4 rounded-2xl p-7">
        <h1 className="text-2xl font-bold">{mode === "up" ? "Create your Givar account" : "Welcome back"}</h1>
        {mode === "up" && <input className={input} placeholder="Full name" value={f.name} onChange={set("name")} required />}
        <input className={input} placeholder="Email or phone number" value={f.identifier} onChange={set("identifier")} required />
        <input className={input} type="password" placeholder="Password (8+ characters)" value={f.password} onChange={set("password")} required minLength={8} />
        {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
        <button disabled={busy} className="w-full rounded-full bg-lime-givar py-3 font-semibold text-black disabled:opacity-60">{busy ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"}</button>
        <button type="button" onClick={() => signIn("google", { callbackUrl: "/dashboard" })} className="glass w-full rounded-full py-3 font-semibold">Continue with Google</button>
        {mode === "in" && <a href="/auth/forgot" className="block text-center text-sm text-[var(--mut)] underline">Forgot password?</a>}
        <button type="button" onClick={() => setMode(mode === "up" ? "in" : "up")} className="w-full text-sm text-[var(--mut)]">{mode === "up" ? "Have an account? Sign in" : "New here? Create an account"}</button>
      </form>
    </main>
  );
}
