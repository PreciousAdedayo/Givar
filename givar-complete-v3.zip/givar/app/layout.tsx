import type { Metadata } from "next";
import { Bricolage_Grotesque } from "next/font/google";
import "./globals.css";
import BottomNav from "@/components/BottomNav";
import TopBar from "@/components/TopBar";
import Tracker from "@/components/Tracker";

const sans = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const site = process.env.NEXT_PUBLIC_SITE_URL ?? "https://givar.app";
const description = "Givar.app is the international giveaway app to create giveaway links & codes, claim cash instantly, and win dinner contests. Get your virtual account number today. Available in Nigeria, USA, UK & worldwide.";

export const metadata: Metadata = {
  metadataBase: new URL(site),
  title: { default: "Givar.app - Global Giveaway Platform", template: "%s | Givar.app - Global Giveaway Platform" },
  description,
  alternates: { canonical: "/" },
  openGraph: { type: "website", siteName: "Givar", title: "Givar - Give. Claim. Win.", description, url: site },
  twitter: { card: "summary_large_image", title: "Givar - Give. Claim. Win.", description },
};

// Runs before paint so the saved light theme doesn't flash dark
const themeScript = `try{if(localStorage.getItem('theme')==='light')document.documentElement.classList.remove('dark')}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className={`${sans.variable} font-sans antialiased pb-24 md:pb-0`}>
        <TopBar />
        {children}
        <BottomNav /><Tracker />
      </body>
    </html>
  );
}
