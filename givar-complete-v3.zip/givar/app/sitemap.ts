import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";
const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://givar.app";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const g = await prisma.giveaway.findMany({ where: { flagged: false, expiresAt: { gt: new Date() } }, select: { id: true, createdAt: true }, take: 5000 }).catch(() => []);
  const c = await prisma.contest.findMany({ where: { drawnAt: null }, select: { id: true }, take: 2000 }).catch(() => []);
  return [
    ...["", "/giveaways", "/contests"].map((p) => ({ url: base + p, changeFrequency: "daily" as const, priority: p ? 0.8 : 1 })),
    ...c.map((x) => ({ url: `${base}/contests/${x.id}`, priority: 0.6 })),
    ...g.map((x) => ({ url: `${base}/giveaways/${x.id}`, lastModified: x.createdAt, priority: 0.6 })),
  ];
}
