"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
const input = "w-full rounded-xl border border-[var(--line)] bg-transparent px-4 py-3 outline-none focus:border-lime-givar";

export default function WalletActions() {
  const r = useRouter(); const [msg, setMsg] = useState("");
  const [amt, setAmt] = useState("");
  const [banks, setBanks] = useState<{ code: string; name: string }[]>([]);
  const [w, setW] = useState({ amount: "", bankCode: "", accountNumber: "" });
  const [holder, setHolder] = useState("");

  useEffect(() => { fetch("/api/banks").then((x) => x.json()).then(setBanks).catch(() => {}); }, []);
  // Confirm the account holder as soon as a bank and 10 digits are entered
  useEffect(() => {
    setHolder("");
    if (!w.bankCode || !/^\d{10}$/.test(w.accountNumber)) return;
    fetch("/api/banks/resolve", { method: "POST", body: JSON.stringify({ bankCode: w.bankCode, accountNumber: w.accountNumber }) })
      .then(async (x) => { const j = await x.json(); setHolder(x.ok ? j.name : ""); if (!x.ok) setMsg(j.error); });
  }, [w.bankCode, w.accountNumber]);

  async function post(url: string, body: object) {
    const res = await fetch(url, { method: "POST", body: JSON.stringify(body) }); const j = await res.json();
    if (!res.ok) return setMsg(j.error); if (j.url) return (location.href = j.url);
    setMsg("Done."); r.refresh();
  }
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <form id="add" className="glass scroll-mt-20 space-y-3 rounded-2xl p-5" onSubmit={(e) => { e.preventDefault(); post("/api/wallet/deposit", { amount: +amt }); }}>
        <h2 className="font-semibold">Add money (NGN)</h2>
        <input className={input} type="number" min="100" placeholder="Amount in ₦" value={amt} onChange={(e) => setAmt(e.target.value)} required />
        <p className="text-xs text-[var(--mut)]">Pay by card, bank transfer or USSD. Or send money to your Givar account number.</p>
        <button className="w-full rounded-full bg-lime-givar py-3 font-semibold text-black">Add money</button>
      </form>
      <form id="withdraw" className="glass scroll-mt-20 space-y-3 rounded-2xl p-5" onSubmit={(e) => { e.preventDefault(); post("/api/wallet/withdraw", { ...w, amount: +w.amount }); }}>
        <h2 className="font-semibold">Withdraw to bank</h2>
        <input className={input} type="number" placeholder="Amount in ₦" value={w.amount} onChange={(e) => setW({ ...w, amount: e.target.value })} required />
        <select className={input} value={w.bankCode} onChange={(e) => setW({ ...w, bankCode: e.target.value })} required><option value="">Choose bank</option>{banks.map((b) => <option key={b.code} value={b.code}>{b.name}</option>)}</select>
        <input className={input} inputMode="numeric" maxLength={10} placeholder="10-digit account number" value={w.accountNumber} onChange={(e) => setW({ ...w, accountNumber: e.target.value })} required />
        {holder && <p className="text-sm text-lime-givar">{holder}</p>}
        <button disabled={!holder} className="glass w-full rounded-full py-3 font-semibold disabled:opacity-50">Withdraw</button>
      </form>
      {msg && <p role="status" className="text-sm md:col-span-2">{msg}</p>}
    </div>
  );
}
