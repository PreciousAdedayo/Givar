import { redirect } from "next/navigation";
import { Prisma, TxType, TxStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getUserId } from "@/lib/session";
import { fmt } from "@/lib/money";
import WalletActions from "./WalletActions";

export const metadata = { title: "Wallet", robots: { index: false } };

export default async function Wallet({ searchParams }: { searchParams: { type?: string; status?: string } }) {
  const userId = await getUserId(); if (!userId) redirect("/auth");
  const where: Prisma.TransactionWhereInput = { wallet: { userId } };
  if (searchParams.type && searchParams.type in TxType) where.type = searchParams.type as TxType;
  if (searchParams.status && searchParams.status in TxStatus) where.status = searchParams.status as TxStatus;
  const [txs, wallets] = await Promise.all([
    prisma.transaction.findMany({ where, orderBy: { createdAt: "desc" }, take: 50, include: { wallet: true } }),
    prisma.wallet.findMany({ where: { userId } }),
  ]);
  const sel = "rounded-xl border border-[var(--line)] bg-transparent px-3 py-2";
  return (
    <main className="mx-auto max-w-4xl space-y-6 px-5 py-8">
      <h1 className="text-2xl font-bold">Wallet</h1>
      <p className="text-[var(--mut)]">{wallets.map((w) => fmt(w.balance, w.currency)).join(" · ") || "No balance yet"}</p>
      <WalletActions />
      <section className="glass rounded-2xl p-5">
        <form className="flex flex-wrap items-center gap-2">
          <h2 className="mr-auto font-semibold">Transactions</h2>
          <select name="type" defaultValue={searchParams.type ?? ""} className={sel}><option value="">All types</option>{Object.keys(TxType).map((t) => <option key={t}>{t}</option>)}</select>
          <select name="status" defaultValue={searchParams.status ?? ""} className={sel}><option value="">All statuses</option>{Object.keys(TxStatus).map((t) => <option key={t}>{t}</option>)}</select>
          <button className="rounded-full bg-lime-givar px-4 py-2 font-semibold text-black">Filter</button>
        </form>
        {txs.length === 0 ? <p className="mt-4 text-[var(--mut)]">No transactions match. Try clearing the filters.</p> :
          <div className="mt-4 overflow-x-auto"><table className="w-full text-left text-sm"><tbody className="divide-y divide-[var(--line)]">
            {txs.map((t) => <tr key={t.id}><td className="py-2">{t.type.replaceAll("_", " ").toLowerCase()}</td><td>{t.status.toLowerCase()}</td><td>{t.createdAt.toLocaleDateString("en")}</td><td className="text-right">{fmt(t.amount, t.wallet.currency)}</td></tr>)}
          </tbody></table></div>}
      </section>
    </main>
  );
}
