import Link from "next/link";
import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { fmt } from "@/lib/money";

export const metadata: Metadata = {
  title: "Live Giveaways",
  description: "Browse live cash giveaways on Givar. Claim giveaways by link or code and get paid instantly.",
  alternates: { canonical: "/giveaways" },
};
export const revalidate = 60;

export default async function Feed({ searchParams }: { searchParams: { q?: string; c?: string } }) {
  const q = searchParams.q?.trim();
  const list = await prisma.giveaway.findMany({
    where: { flagged: false, expiresAt: { gt: new Date() }, winnersLeft: { gt: 0 }, ...(q && { title: { contains: q, mode: "insensitive" } }), ...(searchParams.c === "NGN" || searchParams.c === "USD" ? { currency: searchParams.c } : {}) },
    orderBy: { createdAt: "desc" }, take: 30,
  });
  return (
    <main className="mx-auto max-w-6xl px-5 py-8">
      <h1 className="text-3xl font-bold">Live giveaways</h1>
      <form className="mt-5 flex gap-2"><input name="q" defaultValue={q} placeholder="Search giveaways" className="flex-1 rounded-xl border border-[var(--line)] bg-transparent px-4 py-3" />
        <select name="c" defaultValue={searchParams.c ?? ""} className="rounded-xl border border-[var(--line)] bg-transparent px-3"><option value="">All</option><option>NGN</option><option>USD</option></select>
        <button className="rounded-full bg-lime-givar px-5 font-semibold text-black">Search</button></form>
      {list.length === 0 ? <p className="mt-10 text-[var(--mut)]">No live giveaways match. <Link href="/create" className="underline">Create one</Link>.</p> :
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{list.map((g) => (
          <li key={g.id}><Link href={`/c/${g.claimSlug}`} className="glass block rounded-2xl p-5 transition hover:border-lime-givar">
            <h2 className="font-semibold">{g.title}</h2><p className="mt-2 text-3xl font-bold">{fmt(g.totalAmount, g.currency)}</p>
            <p className="mt-1 text-sm text-[var(--mut)]">{g.winnersLeft} of {g.winners} left</p></Link></li>))}</ul>}
    </main>
  );
}
