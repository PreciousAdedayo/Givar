import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import Avatar from "./Avatar";
import ThemeToggle from "./ThemeToggle";
const links = [["/", "Home"], ["/giveaways", "Giveaways"], ["/contests", "Contests"], ["/wallet", "Wallet"], ["/transactions", "History"]];
/** Desktop navigation. On phones the bottom bar does this job. */
export default async function TopBar() {
  const s = await getServerSession(authOptions);
  return (
    <header className="mx-auto hidden max-w-5xl items-center justify-between px-6 py-4 md:flex">
      <Link href="/" className="flex items-center gap-2 text-xl font-bold">
        <svg width="28" height="28" viewBox="0 0 32 32" fill="none" stroke="#D8F24A" strokeWidth="2" aria-hidden><path d="M16 2 30 16 16 30 2 16Z" /><path d="M16 9 23 16 16 23 9 16Z" /></svg>Givar</Link>
      <nav aria-label="Main" className="flex items-center gap-6 text-sm text-[var(--mut)]">
        {links.map(([h, l]) => <Link key={h} href={h} className="hover:text-[var(--fg)]">{l}</Link>)}
        <ThemeToggle />
        {s ? <Link href="/account" aria-label="Your profile"><Avatar name={s.user.name} size={38} /></Link> : <Link href="/auth" className="bg-lime-givar rounded-full px-5 py-2 font-semibold">Sign in</Link>}
      </nav>
    </header>
  );
}
