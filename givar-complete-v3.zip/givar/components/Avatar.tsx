/* eslint-disable @next/next/no-img-element */
export default function Avatar({ name, image, size = 40 }: { name?: string | null; image?: string | null; size?: number }) {
  const ini = (name ?? "").split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase() || "G";
  const style = { width: size, height: size, fontSize: size * 0.38 };
  return image
    ? <img src={image} alt="" referrerPolicy="no-referrer" style={style} className="shrink-0 rounded-full object-cover" />
    : <span style={style} className="grad-dark text-lime-givar grid shrink-0 place-items-center rounded-full font-semibold" aria-hidden>{ini}</span>;
}
