import { describe, it, expect } from "vitest";
import { toMinor, fmt } from "@/lib/money";
import { newClaimCode, newClaimSlug } from "@/lib/codes";
import { hashPassword, verifyPassword } from "@/lib/password";
import { dailySeries } from "@/lib/series";

describe("money", () => {
  it("converts to minor units without float drift", () => { expect(toMinor(10.1)).toBe(1010); expect(toMinor(0.29)).toBe(29); expect(toMinor(1234.56)).toBe(123456); });
  it("formats currency", () => { expect(fmt(1000000)).toContain("10,000"); expect(fmt(500, "USD")).toContain("5.00"); });
});
describe("codes", () => {
  it("claim codes look right and avoid look-alike characters", () => { for (let i = 0; i < 200; i++) expect(newClaimCode()).toMatch(/^GV-[A-HJKMNP-Z2-9]{6}$/); });
  it("slugs are 9 chars and effectively unique", () => { const s = new Set(Array.from({ length: 1000 }, newClaimSlug)); expect(s.size).toBe(1000); expect([...s][0]).toHaveLength(9); });
});
describe("password", () => {
  it("verifies the right password only", () => { const h = hashPassword("correct horse"); expect(verifyPassword("correct horse", h)).toBe(true); expect(verifyPassword("wrong", h)).toBe(false); });
  it("rejects malformed hashes", () => { expect(verifyPassword("x", "")).toBe(false); expect(verifyPassword("x", "nocolon")).toBe(false); });
  it("salts: same password gives different hashes", () => { expect(hashPassword("a1234567")).not.toBe(hashPassword("a1234567")); });
});
describe("dailySeries", () => {
  it("buckets values into days", () => {
    const rows = dailySeries(3, { a: [{ at: new Date() }, { at: new Date(), v: 4 }] });
    expect(rows).toHaveLength(3); expect(rows[2].a).toBe(5); expect(rows[0].a).toBe(0);
  });
});
