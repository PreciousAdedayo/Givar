import type { NextAuthOptions } from "next-auth";
import Google from "next-auth/providers/google";
import Credentials from "next-auth/providers/credentials";
import { prisma } from "./prisma";
import { verifyPassword } from "./password";
import { limit } from "./ratelimit";
import { provisionUser } from "./virtual-accounts";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/auth" },
  providers: [
    Google({ clientId: process.env.GOOGLE_CLIENT_ID ?? "", clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "" }),
    Credentials({
      credentials: { identifier: {}, password: {} },
      async authorize(c) {
        if (!c?.identifier || !c.password) return null;
        if (!(await limit(`login:${c.identifier.toLowerCase()}`, 10, 900))) return null; // 10 tries / 15 min
        const u = await prisma.user.findFirst({ where: { OR: [{ email: c.identifier.toLowerCase() }, { phone: c.identifier }] } });
        if (!u?.passwordHash || u.banned || !verifyPassword(c.password, u.passwordHash)) return null;
        return { id: u.id, email: u.email, name: u.name };
      },
    }),
  ],
  callbacks: {
    async signIn({ user, account }) {
      if (account?.provider !== "google" || !user.email) return true;
      const email = user.email.toLowerCase();
      let db = await prisma.user.findUnique({ where: { email } });
      if (db?.banned) return false;
      if (!db) { db = await prisma.user.create({ data: { email, name: user.name, image: user.image, emailVerified: true } }); await provisionUser(db); }
      user.id = db.id;
      return true;
    },
    async jwt({ token, user }) {
      if (user?.id) token.id = user.id;
      if (token.id && !token.role) token.role = (await prisma.user.findUnique({ where: { id: token.id as string }, select: { role: true } }))?.role ?? "USER";
      return token;
    },
    async session({ session, token }) {
      if (session.user) { session.user.id = token.id as string; session.user.role = token.role as string; }
      return session;
    },
  },
};
