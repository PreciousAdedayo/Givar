import { prisma } from "./prisma";

const BASE = process.env.FLUTTERWAVE_BASE ?? "https://api.flutterwave.com/v3";
const auth = () => ({ Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET}`, "Content-Type": "application/json" });
export const payoutsConfigured = () => !!process.env.FLUTTERWAVE_SECRET;

export async function listBanks(): Promise<{ code: string; name: string }[]> {
  if (!payoutsConfigured()) return [{ code: "000", name: "Test Bank (dev only)" }];
  const r = await fetch(`${BASE}/banks/NG`, { headers: auth(), next: { revalidate: 86400 } });
  const j = await r.json();
  return j.status === "success" ? j.data.map((b: { code: string; name: string }) => ({ code: b.code, name: b.name })) : [];
}

export async function resolveAccount(bankCode: string, accountNumber: string): Promise<string | null> {
  if (!payoutsConfigured()) return "TEST ACCOUNT";
  const r = await fetch(`${BASE}/accounts/resolve`, { method: "POST", headers: auth(), body: JSON.stringify({ account_number: accountNumber, account_bank: bankCode }) });
  const j = await r.json();
  return j.status === "success" ? j.data.account_name : null;
}

/** "rejected" = provider clearly refused (safe to refund). "unknown" = timeout/network error: the money MAY have left,
 *  so we must NOT refund automatically; the withdrawal stays PENDING for reconciliation. */
export async function sendTransfer(p: { reference: string; amountMinor: number; bankCode: string; accountNumber: string }): Promise<"queued" | "rejected" | "unknown"> {
  try {
    const r = await fetch(`${BASE}/transfers`, {
      method: "POST", headers: auth(), signal: AbortSignal.timeout(15000),
      body: JSON.stringify({ account_bank: p.bankCode, account_number: p.accountNumber, amount: p.amountMinor / 100, currency: "NGN", narration: "Givar withdrawal", reference: p.reference }),
    });
    const j = await r.json();
    if (j.status === "success") return "queued";
    return r.status >= 400 && r.status < 500 ? "rejected" : "unknown";
  } catch {
    return "unknown";
  }
}

/** Final outcome of a withdrawal. Idempotent: only the first call to flip PENDING has any effect.
 *  Failure returns the money to the wallet. */
export async function settleWithdrawal(reference: string, success: boolean) {
  await prisma.$transaction(async (tx) => {
    const t = await tx.transaction.findUnique({ where: { reference } });
    if (!t || t.type !== "WITHDRAWAL") return;
    const flip = await tx.transaction.updateMany({ where: { id: t.id, status: "PENDING" }, data: { status: success ? "SUCCESS" : "FAILED" } });
    if (flip.count === 1 && !success) await tx.wallet.update({ where: { id: t.walletId }, data: { balance: { increment: t.amount } } });
  });
}
