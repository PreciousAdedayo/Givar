import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
export const getUserId = async () => (await getServerSession(authOptions))?.user.id ?? null;
