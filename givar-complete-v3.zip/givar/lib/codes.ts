import { randomInt } from "crypto";
const A = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no look-alike chars (0/O, 1/I/L)
const pick = (n: number) => Array.from({ length: n }, () => A[randomInt(A.length)]).join("");
export const newClaimCode = () => `GV-${pick(6)}`;
export const newClaimSlug = () => pick(9);
