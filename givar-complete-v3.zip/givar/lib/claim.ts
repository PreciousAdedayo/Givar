import { Prisma } from "@prisma/client";
import { prisma } from "./prisma";

export class ClaimError extends Error {}

/** Atomically claims a giveaway. Everything happens in ONE transaction so
 *  concurrent claimers can never over-spend the escrow or claim twice. */
export async function claimGiveaway(slugOrCode: string, userId: string, phone?: string, fingerprint?: string, answer?: string) {
  try {
    return await prisma.$transaction(async (tx) => {
      const found = await tx.giveaway.findFirst({ where: { OR: [{ claimSlug: slugOrCode }, { claimCode: slugOrCode }] }, select: { id: true } });
      if (!found) throw new ClaimError("Giveaway not found.");
      // Row lock: claimers of the same giveaway run one at a time, so the amount maths below never uses stale numbers
      await tx.$queryRaw`SELECT id FROM "Giveaway" WHERE id = ${found.id} FOR UPDATE`;
      const g = await tx.giveaway.findUniqueOrThrow({ where: { id: found.id } });
      if (g.flagged) throw new ClaimError("Giveaway not found.");
      if (g.question && !answer?.trim()) throw new ClaimError("Answer the question to claim.");
      if (g.expiresAt < new Date()) throw new ClaimError("This giveaway has expired.");
      if (g.creatorId === userId) throw new ClaimError("You can't claim your own giveaway.");

      // Amount for this winner (last winner takes any remainder, so escrow empties exactly)
      const avg = Math.floor(g.totalAmount / g.winners);
      let amount = avg;
      if (g.winnersLeft === 1) amount = g.escrowRemaining;
      else if (g.distribution === "RANDOM") {
        const max = Math.min(avg * 2, g.escrowRemaining - (g.winnersLeft - 1));
        amount = 1 + Math.floor(Math.random() * Math.max(max, 1));
      }

      // Conditional decrement: fails (count 0) if someone else took the last slot
      const upd = await tx.giveaway.updateMany({
        where: { id: g.id, winnersLeft: { gt: 0 }, escrowRemaining: { gte: amount } },
        data: { winnersLeft: { decrement: 1 }, escrowRemaining: { decrement: amount } },
      });
      if (upd.count === 0) throw new ClaimError("All prizes have been claimed.");

      await tx.claim.create({ data: { giveawayId: g.id, userId, phone, fingerprint, amount, answer: answer?.trim().slice(0, 300) } });

      const wallet = await tx.wallet.upsert({
        where: { userId_currency: { userId, currency: g.currency } },
        update: { balance: { increment: amount } },
        create: { userId, currency: g.currency, balance: amount },
      });
      // Release from creator's locked funds
      await tx.wallet.update({
        where: { userId_currency: { userId: g.creatorId, currency: g.currency } },
        data: { locked: { decrement: amount } },
      });
      await tx.transaction.create({
        data: { walletId: wallet.id, type: "CLAIM_CREDIT", status: "SUCCESS", amount, reference: `claim_${g.id}_${userId}` },
      });
      return { amount, currency: g.currency, title: g.title };
    });
  } catch (e) {
    // Unique-constraint hit = same user/phone/device already claimed
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002")
      throw new ClaimError("You've already claimed this giveaway.");
    throw e;
  }
}
