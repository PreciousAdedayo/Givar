import { prisma } from "./prisma";
/** Marks a pending deposit successful and credits the wallet. Idempotent via the PENDING->SUCCESS guard. */
export async function settleDeposit(reference: string) {
  await prisma.$transaction(async (tx) => {
    const t = await tx.transaction.findUnique({ where: { reference } });
    if (!t) return;
    const flip = await tx.transaction.updateMany({ where: { id: t.id, status: "PENDING" }, data: { status: "SUCCESS" } });
    if (flip.count === 1) await tx.wallet.update({ where: { id: t.walletId }, data: { balance: { increment: t.amount } } });
  });
}
