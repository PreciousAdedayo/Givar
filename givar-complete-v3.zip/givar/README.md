# Givar.app — Give. Claim. Win.

Next.js 14 (App Router) · TypeScript · Tailwind · Prisma/PostgreSQL · NextAuth · Recharts · Framer Motion

## Run locally
```bash
npm install
cp .env.example .env        # set DATABASE_URL and NEXTAUTH_SECRET (openssl rand -base64 32)
npx prisma migrate dev --name init
npm run dev
npm run make-admin -- you@email.com   # after signing up
```
With no provider keys, everything runs in **dev mode**: test virtual accounts, instant fake deposits, codes/emails/SMS printed to the console. Dev shortcuts are disabled when `NODE_ENV=production`.

## Tests
```bash
npm test                                             # unit tests
TEST_DATABASE_URL=postgresql://... npx prisma db push && npm test   # + money-path integration tests (disposable DB only!)
```

## Layout
- `prisma/schema.prisma` – all models. Money is stored in minor units (kobo/cents).
- `lib/claim.ts` – atomic claim + escrow release (row-locked). `lib/refund.ts` – escrow refunds.
- `lib/payout.ts` – Flutterwave bank list, name lookup, transfers, settle/refund.
- `lib/virtual-accounts.ts` – NGN (Flutterwave) / USD (Strowallet, **stub**) account provisioning.
- `app/api/webhooks/*` – Flutterwave, Paystack, Strowallet (**field names guessed**).
- `app/api/cron/draw-contests` – contest draws, expired-giveaway refunds, cleanup (daily via `vercel.json`).
- `app/admin` – analytics + management (ADMIN role only).
